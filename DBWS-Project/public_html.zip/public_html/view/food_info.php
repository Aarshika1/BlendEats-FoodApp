<!DOCTYPE html>
<html lang="en">

<?php 
$age_title="Details Page";
include("../header.php")?>
<body>
<?php include("../nav.php")?>
<div class="container mt-5">
<?php
    $servername = "10.72.1.14";
    $username = "group2";
    $dbpass = "6QOIHm";
    $dbname = "group2";

    $conn = new mysqli($servername, $username, $dbpass, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } 
    $fid = $_GET['fid'];

    $sql = "SELECT * FROM food WHERE fid = $fid ;";
    if($result = mysqli_query($conn, $sql)){
        if(mysqli_num_rows($result) > 0){
            echo "<table cellspacing=3 cellpadding=4>";
                echo "<tr>";
                    echo "<th>Name </th>";
                    echo "<th>Price </th>";
                    echo "<th>Description</th>";
                echo "</tr>";
            while($row = mysqli_fetch_array($result)){
                echo "<tr>";
                    echo "<td>". $row['title'] . "</td>";
                    echo "<td>" . $row['price'] . "</td>";
                    echo "<td>" . $row['description']. "</td>";
                echo "</tr>";
            }
            echo "</table>";
            mysqli_free_result($result);
        } else{
            echo "No records matching your query were found.";
        }
    } else{
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
    }

    $conn->close();

?>
<br>
<a class ="btn btn-primary" href = "../search">Search Page</a>

</div>
<?php include("../footer.php") ?>

</body>
</html>