<!DOCTYPE html>
<html lang="en">

<?php
include('../conn.php');
$age_title="Result Page";
include("../header.php")?>
<body>

<div class="container mt-5">
<?php
    $conn = new mysqli($servername, $username, $dbpass, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $bestbefore= $_GET['bestbefore'];

   
    $sql = "SELECT food.title, packaged_food.bestbefore, food.fid FROM food
     JOIN packaged_food ON food.fid = packaged_food.fid
     WHERE bestbefore < DATE_ADD(NOW(), INTERVAL $bestbefore MONTH) 
     AND bestbefore > NOW(); ";
     
    if($result = mysqli_query($conn, $sql)){
        if(mysqli_num_rows($result) > 0){
            echo "<table>";
              echo "<tr>";
                    echo "<th>Name</th>";
                    echo "<th>Bestbefore</th>";
                echo "</tr>";
            while($row = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td> <a href = '../view/food_info.php?fid=$row[fid]' > $row[title]  </a> </td>";
                    echo "<td>" . $row['bestbefore'] . "</td>";
                    echo "</tr>";
            }
            echo "</table>";
            mysqli_free_result($result);
        } else{
            echo "No records matching your query were found.";
        }
    } else{
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
    }

    $conn->close();

?>
<br>
<a class ="btn btn-primary" href = "../search/">Search Page</a>

</div>

</body>
</html>
